package models

import (
	"github.com/snail007/go-activerecord/mysql"
)

var G *mysql.DBGroup

var Version string

