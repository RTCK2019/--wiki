package main

import (
	_"mm-wiki/app"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}
