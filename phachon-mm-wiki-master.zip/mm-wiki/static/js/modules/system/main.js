/**
 * main.js
 * Copyright (c) 2018 phachon@163.com
 */